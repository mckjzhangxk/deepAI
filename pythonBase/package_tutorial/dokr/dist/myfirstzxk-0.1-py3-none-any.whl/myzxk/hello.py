def sayHello():
    print('hello')
class foo():
    def __init__(self):
        pass
    def sayHello(self):
        print('hello foo')
if __name__ == "__main__":
    sayHello()